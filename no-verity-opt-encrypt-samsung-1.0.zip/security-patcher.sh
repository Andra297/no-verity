#!/sbin/sh

console=$(cat /tmp/console)
[ "$console" ] || console=/proc/$$/fd/1

efs_block=

print() {
	if [ "$1" ]; then
		echo "ui_print - $1" > "$console"
	else
		echo "ui_print  " > "$console"
	fi
	echo
}

abort() {
	[ "$1" ] && {
		print "Error: $1!"
		print "Aborting..."
	}
	exit 1
}

find_efs() {
	verify_block() {
		efs_block=$(readlink -f "$efs_block")
		# if the efs block is a file, we must use dd
		if [ -f "$efs_block" ]; then
			use_dd=true
		# if the efs block is a block device, we use flash_image when possible
		elif [ -b "$efs_block" ]; then
			case "$efs_block" in
				/dev/block/bml*|/dev/block/mtd*|/dev/block/mmc*)
					use_dd=false ;;
				*)
					use_dd=true ;;
			esac
		# otherwise we have to keep trying other locations
		else
			return 1
		fi
		print "Found efs partition at: $efs_block"
	}
	# if we already have efs block set then verify and use it
	[ "$efs_block" ] && verify_block && return
	# otherwise, time to go hunting!
	if [ -f /etc/recovery.fstab ]; then
		# recovery fstab v1
		efs_block=$(awk '$1 == "/efs" {print $3}' /etc/recovery.fstab)
		[ "$efs_block" ] && verify_block && return
		# recovery fstab v2
		efs_block=$(awk '$2 == "/efs" {print $1}' /etc/recovery.fstab)
		[ "$efs_block" ] && verify_block && return
	fi
	for fstab in /fstab.*; do
		[ -f "$fstab" ] || continue
		# device fstab v2
		efs_block=$(awk '$2 == "/efs" {print $1}' "$fstab")
		[ "$efs_block" ] && verify_block && return
		# device fstab v1
		efs_block=$(awk '$1 == "/efs" {print $3}' "$fstab")
		[ "$efs_block" ] && verify_block && return
	done
	if [ -f /proc/emmc ]; then
		# emmc layout
		efs_block=$(awk '$4 == "\"efs\"" {print $1}' /proc/emmc)
		[ "$efs_block" ] && efs_block=/dev/block/$(echo "$efs_block" | cut -f1 -d:) && verify_block && return
	fi
	if [ -f /proc/mtd ]; then
		# mtd layout
		efs_block=$(awk '$4 == "\"efs\"" {print $1}' /proc/mtd)
		[ "$efs_block" ] && efs_block=/dev/block/$(echo "$efs_block" | cut -f1 -d:) && verify_block && return
	fi
	if [ -f /proc/dumchar_info ]; then
		# mtk layout
		efs_block=$(awk '$1 == "/efs" {print $5}' /proc/dumchar_info)
		[ "$efs_block" ] && verify_block && return
	fi
	abort "Unable to find efs block location"
}

mount_efs() {
    print "Mounting EFS partition..."
    mount -o rw $efs_block /efs
}

patch_prop() {
    print "Adding security property overrides..."
    sed -i '/vaultkeeper/d' /efs/factory.prop
    sed -i '/pst/d' /efs/factory.prop
    echo "ro.security.vaultkeeper.feature=0" >> /efs/factory.prop
    echo "ro.frp.pst=/dev/block/dummy" >> /efs/factory.prop
}

unmount_efs() {
    umount /efs
}

unmount_efs
find_efs
mount_efs
patch_prop
unmount_efs
